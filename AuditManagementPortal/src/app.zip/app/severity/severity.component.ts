import { Component, OnInit } from '@angular/core';
import { Severity } from '../Services/severity.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuditResponse } from '../Models/auditResponse.model';
import { Router } from '@angular/router';
import { Security } from '../Services/security.service';
import { GetQuestionsList } from '../Services/getQuestionList.service';
import { analyzeFileForInjectables } from '@angular/compiler';

@Component({
  selector: 'app-severity',
  templateUrl: './severity.component.html',
  styleUrls: ['./severity.component.css']
})
export class SeverityComponent implements OnInit {
  
  public finalRes:any;
  public resStatus:string="";
  
  constructor(private sev:Severity,
    private router:Router,
    private security:Security,
    private qList:GetQuestionsList) { }
    auditResponse =new AuditResponse(0 ,"","","","");

  ngOnInit(): void {
    if(!this.security.checkLogin())
    this.router.navigate(['unauthorisedError']);
    this.getexecutionStatus();
  }

  getexecutionStatus(){
    var temp:any;
    this.sev.executionStatus()  //returns an observable
    .subscribe(response=>{
      
      temp = response;
      //console.log(temp);
      
    },error=>{
      console.log(error.message);
    },
    ()=>
    { 
      this.setResults(temp);
    });
  }

  setResults(finalRes:any){
    //console.log(finalRes);
    this.finalRes.auditId = Math.abs(this.auditResponse.auditId);
    //this.auditResponse.auditId =Math.abs(finalRes.auditId);
   // this.auditResponse.projectStatus =finalRes.ProjectExecutionStatus;
   //console.log(finalRes);
     if(finalRes.remedialActionDuration =="No Action Needed"){
   
        this.auditResponse.projectStatus="Green";
        }
        else{
        this.auditResponse.projectStatus="Red";
        } 
    //this.auditResponse.projectStatus="Red";
    this.auditResponse.remedyAction=finalRes.remedialActionDuration;
    this.auditResponse.projectName=this.qList.getProjectName();
    this.auditResponse.managerName=this.security.getUserName();

    this.resStatus=finalRes.remedialActionDuration;
  }

}
