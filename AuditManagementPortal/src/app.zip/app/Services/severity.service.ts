
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Injectable, Inject} from "@angular/core";
import { Router } from '@angular/router';
import { SeverityURL } from '../Models/tokens';
import { GetQuestionsList } from './getQuestionList.service';
import { Security } from './security.service';


@Injectable({providedIn: 'root'})

export class Severity{
    private token=localStorage.getItem('auditToken');

    headers={
      headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Authorization':`Bearer ${this.token}`
      })
    }

    constructor(private http:HttpClient,
      private route:Router,
      private qList:GetQuestionsList,
      private security:Security,
      @Inject(SeverityURL) private severityUrl:string
      ){

    }

    requestData1=
    {
      "projectName": "",
      "projectManagerName": "",
      "applicationOwnerName": "",
      "auditDetails": {
        "type": "",
        "date": "",
         "questions" :
          {
            "question1": false,
            
          
            "question2": false,
            
          
            "question3": false,
            
            "question4": false,
            "question5": false

      }
    }
    };
    
    setDetails(){
      this.requestData1.projectName=this.qList.getProjectName(),
   this.requestData1.projectManagerName=this.security.getUserName(),
  this.requestData1.applicationOwnerName= "Sreedhar";
  if(this.qList.getAuditType() == 0){
    this.requestData1.auditDetails.type="Internal";
  }else{
    this.requestData1.auditDetails.type="SOX";
  }
  
  this.requestData1.auditDetails.date=new Date().toISOString();
  var res: 
    {questionId:number, answer:string}[] = this.qList.sendResponse();
    const ans = res.map((obj)=>obj.answer);
    const ques = res.map((obj1)=>obj1.questionId);
  for(let i=0;i<ans.length;i++){
     if(ans[i]==="YES")
        if(ques[i] == 1){
             this.requestData1.auditDetails.questions.question1 = true;
        }
          else  
           if(ques[i] == 2){
            this.requestData1.auditDetails.questions.question2 = true;
          }
          else  
           if(ques[i] == 3){
            this.requestData1.auditDetails.questions.question3 = true;
          }
          else  
           if(ques[i] == 4){
            this.requestData1.auditDetails.questions.question4 = true;
          }
          if(ques[i] == 5){
            this.requestData1.auditDetails.questions.question5 = true;
          }

     else
     if(ans[i] =="NO"){
          if(ques[i] == 1){
            this.requestData1.auditDetails.questions.question1 = false;
      }
        else  
          if(ques[i] == 2){
          this.requestData1.auditDetails.questions.question2 = false;
        }
        else  
          if(ques[i] == 3){
          this.requestData1.auditDetails.questions.question3 = false;
        }
        else  
          if(ques[i] == 4){
          this.requestData1.auditDetails.questions.question4 = false;
        }
        if(ques[i] == 5){
          this.requestData1.auditDetails.questions.question5 = false;
        }

      }
  }
    
  }
    getTokFromlocal(){
      return this.token;
    }


    public executionStatus(){
      this.setDetails();
      //return this.requestData1;
      const body=(this.requestData1);
      console.log(body);
      return this.http.post<any>(this.severityUrl,body,{responseType:'object' as 'json'});
      }

}
