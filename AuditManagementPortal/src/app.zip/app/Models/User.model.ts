export class User{
    constructor(public userName:string, public isLogin:boolean){}     
}