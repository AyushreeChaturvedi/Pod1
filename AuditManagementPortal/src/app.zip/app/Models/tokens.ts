import { InjectionToken } from "@angular/core";


export const AuthURL=new InjectionToken<string>('');
export const SeverityURL=new InjectionToken<string>('');
export const QuesURL=new InjectionToken<string>('');

